<?php
/*
Plugin Name: JBlog Core
Plugin URI: https://wordpress.org
Description: This is jblog core plugin.
Version: 1.0
Author: Habibur Rahman
Author URI: https://facebook.com/habibur5g
License: GPLv2 or later
Text Domain: jblog
Domain Path: /languages/
 */



function jblog_core_plugin() {
	load_plugin_textdomain( 'jblog', false, plugin_dir_path( __FILE__ ) . '/languages' );
}

add_action( 'plugin_loaded', 'jblog_core_plugin' );

//For Svg Support
require_once plugin_dir_path(__FILE__).'/inc/svg-support.php';
require_once plugin_dir_path(__FILE__).'/inc/postview-count.php';
